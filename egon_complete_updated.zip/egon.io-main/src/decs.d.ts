declare module 'DomainStoryModeler';
declare module 'dsActivityHandlers';
