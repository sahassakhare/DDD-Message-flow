export const environment = {
  production: true,
  version: '2.3.1',
};
