import { Dictionary } from './dictionary';

export interface IconSet {
  name: string;
  actors: Dictionary;
  workObjects: Dictionary;
}
