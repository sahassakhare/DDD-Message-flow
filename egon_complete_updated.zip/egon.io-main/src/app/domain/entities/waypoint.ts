export interface Waypoint {
  x: number;
  y: number;
  original: {
    x: number;
    y: number;
  };
}
