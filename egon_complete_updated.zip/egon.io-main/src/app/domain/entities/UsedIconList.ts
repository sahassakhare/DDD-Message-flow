export interface UsedIconList {
  actors: string[];
  workobjects: string[];
}
