export interface IconSetConfigurationForExport {
  name: string;
  actors: any;
  workObjects: any;
}
