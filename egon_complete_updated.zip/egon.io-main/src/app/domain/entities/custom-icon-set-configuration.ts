export interface CustomIconSetConfiguration {
  name: string;
  actors: string[];
  workObjects: string[];
}
