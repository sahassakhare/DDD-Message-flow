export interface IconListItem {
  name: string;
  svg: string;
  isActor: boolean;
  isWorkObject: boolean;
}
