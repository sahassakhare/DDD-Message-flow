import { Component } from '@angular/core';

@Component({
  selector: 'app-autosave-settings',
  templateUrl: './autosave-settings.component.html',
  styleUrls: ['./autosave-settings.component.scss'],
})
export class AutosaveSettingsComponent {}
