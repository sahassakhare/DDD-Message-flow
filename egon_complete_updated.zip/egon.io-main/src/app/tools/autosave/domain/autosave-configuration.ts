export interface AutosaveConfiguration {
  activated: boolean;
  maxDrafts: number;
  interval: number;
}
