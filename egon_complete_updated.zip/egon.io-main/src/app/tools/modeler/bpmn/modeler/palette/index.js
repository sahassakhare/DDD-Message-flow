import DSModeling from "../modeling/dSModeling";

export default {
  __depends__: [],
  __init__: ["paletteProvider"],
  modeling: ["type", DSModeling],
};
