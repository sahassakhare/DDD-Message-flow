export interface BrowserSpecs {
  name: string;
  version: string;
}
