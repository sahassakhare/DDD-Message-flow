export interface Box {
  xLeft: number;
  xRight: number;
  yUp: number;
  yDown: number;
}
