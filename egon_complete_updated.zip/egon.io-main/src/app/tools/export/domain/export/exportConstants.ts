export const SVG_LINK = 'http://www.w3.org/2000/svg';
export const X_OFFSET_UTIL = '8';
export const TEXTSPAN_TITLE_HEIGHT = 30;
export const TEXTSPAN_DESCRIPTION_HEIGHT = 15;
export const DEFAULT_PADDING = 15;
