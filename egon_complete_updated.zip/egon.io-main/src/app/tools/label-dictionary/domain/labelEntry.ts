export interface LabelEntry {
  name: string;
  originalName: string;
}
