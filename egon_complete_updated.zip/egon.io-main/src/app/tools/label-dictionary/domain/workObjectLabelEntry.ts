import { LabelEntry } from './labelEntry';

export interface WorkObjectLabelEntry extends LabelEntry {
  icon: string;
}
